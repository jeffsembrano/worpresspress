<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="<?php echo get_template_directory_uri()?> /images/favicon.ico" type="image/ico" />

    <?php wp_head(); ?>

    <title>Gentelella Alela! | </title>

     <!-- Bootstrap -->
    <link href="/wordpress/wp-content/themes/gentelellasample/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="/wordpress/wp-content/themes/gentelellasample/css/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="/wordpress/wp-content/themes/gentelellasample/nprogress/nprogress.css" rel="stylesheet">
     <!-- iCheck -->
    <link href="/wordpress/wp-content/themes/gentelellasample/css/green.css" rel="stylesheet">
  
    <!-- bootstrap-progressbar -->
    <link href="/wordpress/wp-content/themes/gentelellasample/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="/wordpress/wp-content/themes/gentelellasample/jqvmap/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="/wordpress/wp-content/themes/gentelellasample/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="/wordpress/wp-content/themes/gentelellasample/css/custom.min.css" rel="stylesheet">

  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">